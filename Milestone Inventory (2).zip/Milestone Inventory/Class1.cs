﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone_Inventory
{
    public class Item
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }

        public override string ToString()
        {
            return $"Name: {Name}, Price: {Price}, Quantity: {Quantity}";
        }
    }

    public class InventoryManager
    {
        public List<Item> inventory;

        public InventoryManager()
        {
            inventory = new List<Item>();
        }

        public void AddItem(Item item)
        {
            inventory.Add(item);
        }

        public void RemoveItem(Item item)
        {
            inventory.Remove(item);
        }

        public void RestockItem(Item item, int quantity)
        {
            item.Quantity += quantity;
        }

        public List<Item> SearchItems(string name, decimal price)
        {
            var searchResults = inventory.Where(item =>
                item.Name.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0 &&
                item.Price <= price).ToList();

            return searchResults;
        }
    }
}
