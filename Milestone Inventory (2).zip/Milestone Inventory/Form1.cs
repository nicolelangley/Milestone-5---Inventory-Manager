﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Milestone_Inventory
{

    public partial class Form1 : Form
    {
        private InventoryManager inventoryManager;
        public Form1()
        {
                InitializeComponent();
                inventoryManager = new InventoryManager();
        }

        //add method to add items to inventory
        private void addButton_Click(object sender, EventArgs e)
        {
            string name = nameTextBox.Text.Trim();
            decimal price = decimal.Parse(priceTextBox.Text);
            int quantity = int.Parse(quantityTextBox.Text);

            var item = new Item
            {
                Name = name,
                Price = price,
                Quantity = quantity
            };

            inventoryManager.AddItem(item);
            RefreshInventoryList();
            ClearInputFields();
        }

        //Remove method removes an item from inventory 
        private void button1_Click(object sender, EventArgs e)
        {
            var selectedItem = inventoryListBox.SelectedItem as Item;
            if (selectedItem != null)
            {
                inventoryManager.RemoveItem(selectedItem);
                inventoryListBox.Items.Remove(selectedItem);
            }
            RefreshInventoryList();
        }

        //Restock method, restocks items in inventory 
        private void restockButton_Click(object sender, EventArgs e)
        {
            var selectedItem = inventoryListBox.SelectedItem as Item;
            if (selectedItem != null)
            {
                int quantity;
                if (int.TryParse(quantityTextBox.Text, out quantity) && quantity > 0)
                {
                    inventoryManager.RestockItem(selectedItem, quantity);
                    RefreshInventoryList();
                }
                else
                {
                    MessageBox.Show("Please enter a valid positive quantity.");
                }
            }
        }

        //Search method, search for an item in inventory using name and price
        private void searchButton_Click(object sender, EventArgs e)
        {
            string name = nameTextBox.Text.Trim();
            decimal price = decimal.Parse(priceTextBox.Text);

            var searchResults = inventoryManager.SearchItems(name, price);

            // Display search results
            inventoryListBox.Items.Clear();
            foreach (var item in searchResults)
            {
                inventoryListBox.Items.Add(item);
            }
        }

        private void RefreshInventoryList()
        {
            inventoryListBox.Items.Clear();
            foreach (var item in inventoryManager.inventory)
            {
                inventoryListBox.Items.Add(item.ToString());
            }
        }

        private void ClearInputFields()
        {
            nameTextBox.Clear();
            priceTextBox.Clear();
            quantityTextBox.Clear();
        }
    }
}
